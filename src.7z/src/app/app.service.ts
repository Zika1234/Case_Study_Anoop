import { Injectable } from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {Observable} from "rxjs"

@Injectable({
  providedIn: 'root'
})
export class TakeAndShowService {
//   private url : string = "http://localhost:1234/rest/api/read";

//   constructor(private http:HttpClient){}

//   getValues(){
//       return this.http.get(this.url);
//   }

//   postValues(sendName:string,sendAge:number):Observable<object>{
//       console.log(sendName+sendAge);
//      return this.http.post('http://localhost:1234/rest/api/readpost',{
//           name:sendName,
//           age:sendAge
//       })
//   }
constructor(private http: HttpClient) { }

readData():Observable<Object>{
  return this.http.get('http://localhost:1234/rest/api/read')
}

postData(prodid:number, prodname: string, pdes:string, pprice:number):Observable<Object>{
  console.log("service running");
  return this.http.post('http://localhost:1234/rest/api/write', {
    pid: prodid,
    pname: prodname,
    price: pprice,
    description: pdes
  })
}

 postDataDelete(ename:string):Observable<Object>{
   console.log('service works')
  return this.http.post('http://localhost:1234/rest/api/delete', {
    pname: ename
     
  })
  
}

postDataUpdate(pid:number,pname:string,ename:string, eprice: number,edescription:string):Observable<Object>{
 
  //console.log("Hertettrrtre");
  console.log(pname);
 
 
  return this.http.post('http://localhost:1234/rest/api/update', {
    id:pid,
    oname:pname,
    name: ename,
    price:eprice,
    description:edescription,
  })
}

postDeleteAllData():Observable<Object>{
  console.log('deleteAll service');
  return this.http.post('http://localhost:1234/rest/api/deleteAll');
}

}


