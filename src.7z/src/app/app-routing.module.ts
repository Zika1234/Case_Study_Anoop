import { NgModule } from '@angular/core';
import {HomeComponent} from './home/home.component'
import { RouterModule, Routes } from '@angular/router';
import {AppComponent} from './app.component';
import {AddProductComponent} from './add-product/add-product.component';
import {RouteComponent} from './route/route.component';
import {UpdateformComponent} from "./update/update.component"

const routes: Routes = [
    { path: 'home', component: HomeComponent },
   { path: 'addProduct', component: AddProductComponent },
    { path: 'rouuute', component: RouteComponent },
    { path: 'update', component: UpdateformComponent }

];
@NgModule({
  imports: [
  RouterModule.forRoot(routes) 
  ],
  
   exports: [ RouterModule ],
  declarations: []
  
})

export class AppRoutingModule { }
