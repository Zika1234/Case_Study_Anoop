import { Component, OnInit } from '@angular/core';
import {Router} from "@angular/router";
import {TablestoupdateService} from "../tablestoupdate.service";
import {TakeAndShowService} from "../app.service";



@Component({
  selector: 'app-updateform',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateformComponent implements OnInit {

  constructor(private updateToTable:TablestoupdateService,private app:TakeAndShowService,private router:Router) { }

  showArr:any;

changeId:number;
changeName:string;
changeDescription:string;
changePrice:number;

index:number;
showForm:boolean = false;
showId:number;
showName:string;
showDescription:string;
showPrice:number;
oName = this.showName;

  ngOnInit() {
    console.log(this.updateToTable.getId());
   this.showArr = this.updateToTable.getArr();
   console.log(this.showArr);
  let id = this.updateToTable.getId();
  this.showForm = true;
  console.log(id);
  this.changeId = this.showArr[id].pid;
  this.changeName = this.showArr[id].pname;
  this.changePrice = this.showArr[id].price;
  this.changeDescription = this.showArr[id].description;
  this.index = id;
  this.oName = this.showArr[id].pname;
  console.log(this.showForm,this.showPrice);

  }

  onUpdate(){
    console.log(this.changeName);
    this.app.postDataUpdate(this.changeId,this.oName,this.changeName,this.changePrice,this.changeDescription).subscribe();
    alert("Updated");
  
  }

  onTables(){
    this.router.navigateByUrl('home');
  }
  

}