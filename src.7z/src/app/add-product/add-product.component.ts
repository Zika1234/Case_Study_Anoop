import { Component, OnInit } from '@angular/core';
import {TakeAndShowService} from '../app.service';
import {Router} from '@angular/router';
import {NgForm} from '@angular/forms'

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css']
})
export class AddProductComponent implements OnInit {

  constructor(private take:TakeAndShowService, private route:Router) { }

  ngOnInit() {
  }

   prodname:string;
   prodprice:number;
   prodDes:string;
   prodid:number;

     writePost(AddForm:NgForm){

       this.prodid = AddForm.controls['Pid'].value;
  this.prodname = AddForm.controls['Pname'].value;
  this.prodDes = AddForm.controls['Pdescp'].value;
  this.prodprice = AddForm.controls['Pprice'].value;
  //this.showAdd = true;
    console.log(this.prodid+this.prodname+this.prodDes+this.prodprice)
    this.take.postData(this.prodid,this.prodname,this.prodDes,this.prodprice).subscribe();
    //this.route.navigateByUrl('home');
    alert("Product Added");
  }
  goHome(){
     this.route.navigateByUrl('home');
  }


}
