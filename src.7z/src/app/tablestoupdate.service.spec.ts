import { TestBed } from '@angular/core/testing';

import { TablestoupdateService } from './tablestoupdate.service';

describe('TablestoupdateService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: TablestoupdateService = TestBed.get(TablestoupdateService);
    expect(service).toBeTruthy();
  });
});
