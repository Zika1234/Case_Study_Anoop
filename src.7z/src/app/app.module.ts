import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import {FormsModule} from "@angular/forms"
import {HttpClientModule} from "@angular/common/http";
import { AddProductComponent } from './add-product/add-product.component';
import { AppRoutingModule } from './/app-routing.module';
import { HomeComponent } from './home/home.component';
import {NgxPaginationModule} from 'ngx-pagination';
import { RouteComponent } from './route/route.component';
import { UpdateformComponent } from './update/update.component';

@NgModule({
  declarations: [
    AppComponent,
    AddProductComponent,
    HomeComponent,
    RouteComponent,
    UpdateformComponent,
    
  ],
  imports: [
    BrowserModule,FormsModule,HttpClientModule, AppRoutingModule, NgxPaginationModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
