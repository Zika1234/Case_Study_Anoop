import { Component, OnInit } from '@angular/core';
import {TakeAndShowService} from '../app.service';
import {HttpClient} from "@angular/common/http";
import {Router} from '@angular/router';
import {TablestoupdateService} from '../tablestoupdate.service';


@Component({
  selector: 'app-hroot',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit{
  check:any;
  sendName:string;
  arr:any[] = [];

 constructor(private take:TakeAndShowService, private route:Router,private tablesToUpdate: TablestoupdateService ){}
//   exp = require('express');
//  parser = require('body-parser');
//  app = this.exp();
//  fr = require('fs');
ngOnInit(){
    let x:string;
    this.take.readData().subscribe(d=>{
    // console.log(d);
    // x = JSON.stringify(d);
    // this.check = d;
    // this.arr = this.check;

         console.log(d);
     let  data = d;
     let i;
    //  let len = d.length;
    //  for(i = 0;i < len;i++){
    //    this.arr.push(d[i]);
    //    console.log("here");
    //  }
      this.check = data;
      this.arr = this.check;
      // console.log(d.length);
   });

}

addClick(){
  this.route.navigateByUrl('addProduct');
}

     deleteClick(x){
       this.sendName = x;
       this.take.postDataDelete(this.sendName).subscribe();
       this.route.navigateByUrl('rouuute');

       location.reload(true);
     }

     onUpdateShow(name){
  let id:number;
  let allRegister = this.arr;
  let index = allRegister.findIndex(oneRegister => oneRegister.pname === name);
  //allRegister.splice(index,1);
  //this.router.navigateByUrl('update');
   id = index;
  // console.log(id+","+name);
  // this.showForm = true;
  // this.showName = this.showArr[id].name;
  // this.showPrice = this.showArr[id].price;
  // this.showDescription = this.showArr[id].description;
  // this.index = id;
  // this.oName = this.showArr[id].name;

    console.log(id+""+name+""+this.arr);
  this.tablesToUpdate.set(this.check,id);
  this.route.navigateByUrl('update');
 
}

deleteAllClick(){
  this.take.postDeleteAllData().subscribe();
   location.reload(true);
}

}

