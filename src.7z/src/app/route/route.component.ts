import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';

@Component({
  selector: 'app-route',
  templateUrl: './route.component.html',
  styleUrls: ['./route.component.css']
})
export class RouteComponent implements OnInit {

  constructor(private route:Router) { }

  ngOnInit() {
   this.anyFunction();
  }

  anyFunction(){
     this.route.navigateByUrl('home');
  }

}
